# -*- coding: utf-8 -*-
# Ио — виртуальный агент на базе модели ВНД (глобальное рабочее пространство)
# Часть 1: данные, лемматизация, книги, демо-корпус
import os, sys, re, pickle, threading, traceback
from collections import Counter, defaultdict, deque
import numpy as np

np.random.seed(7)

try:
    import pymorphy3
    _morph = pymorphy3.MorphAnalyzer()
except Exception:
    _morph = None

STOP = set('и в на с из по к у о об от для что как это не ни а но или же бы ли'.split()) | {
    'кто', 'где', 'когда', 'почему', 'зачем', 'каким', 'какого', 'чем', 'того',
    'чтобы', 'если', 'там', 'the', 'of', 'a', 'is', 'and', 'in'}
MAXV = 1500  # максимум лемм в словаре

ACC = {'человек': 'человека', 'стул': 'стул', 'табурет': 'табурет', 'стол': 'стол',
    'кровать': 'кровать', 'диван': 'диван', 'пол': 'пол', 'окно': 'окно',
    'чашка': 'чашку', 'стакан': 'стакан', 'тарелка': 'тарелку', 'кот': 'кота',
    'собака': 'собаку', 'птица': 'птицу', 'дерево': 'дерево', 'лампа': 'лампу',
    'книга': 'книгу', 'дверь': 'дверь', 'машина': 'машину', 'снег': 'снег',
    'вода': 'воду', 'чай': 'чай', 'огонь': 'огонь', 'свет': 'свет', 'трава': 'траву',
    'цветок': 'цветок', 'дождь': 'дождь', 'ветер': 'ветер', 'луна': 'луну',
    'солнце': 'солнце', 'дом': 'дом', 'комната': 'комнату', 'стена': 'стену',
    'шкаф': 'шкаф', 'подушка': 'подушку', 'одеяло': 'одеяло', 'палка': 'палку',
    'камень': 'камень', 'ребёнок': 'ребёнка', 'ключ': 'ключ', 'лодка': 'лодку',
    'лес': 'лес', 'звезда': 'звезду', 'пища': 'пищу', 'звук': 'звук', 'тень': 'тень',
    'туча': 'тучу', 'роса': 'росу', 'песок': 'песок', 'соль': 'соль', 'хлеб': 'хлеб',
    'молоко': 'молоко', 'яблоко': 'яблоко', 'гриб': 'гриб', 'лист': 'лист',
    'ветка': 'ветку', 'земля': 'землю', 'небо': 'небо', 'облако': 'облако',
    'река': 'реку', 'море': 'море', 'берег': 'берег', 'тропа': 'тропу',
    'мышь': 'мышь', 'заяц': 'зайца', 'лиса': 'лису', 'корова': 'корову',
    'конь': 'коня', 'письмо': 'письмо', 'песня': 'песню', 'музыка': 'музыку',
    'сказка': 'сказку', 'подарок': 'подарок', 'деньги': 'деньги', 'магазин': 'магазин',
    'рассвет': 'рассвет', 'закат': 'закат', 'утро': 'утро', 'вечер': 'вечер',
    'зима': 'зиму', 'лето': 'лето', 'праздник': 'праздник', 'зеркало': 'зеркало',
    'часы': 'часы', 'кольцо': 'кольцо', 'монета': 'монету', 'бутылка': 'бутылку',
    'ведро': 'ведро', 'корзина': 'корзину', 'платок': 'платок', 'смысл': 'смысл',
    'время': 'время', 'сон': 'сон', 'путь': 'путь', 'вкус': 'вкус', 'запах': 'запах',
    'гость': 'гостя'}

PREP = {'человек': 'человеке', 'стул': 'стуле', 'табурет': 'табурете', 'стол': 'столе',
    'кровать': 'кровати', 'диван': 'диване', 'пол': 'полу', 'окно': 'окне',
    'чашка': 'чашке', 'стакан': 'стакане', 'тарелка': 'тарелке', 'кот': 'коте',
    'собака': 'собаке', 'птица': 'птице', 'дерево': 'дереве', 'лампа': 'лампе',
    'книга': 'книге', 'дверь': 'двери', 'машина': 'машине', 'снег': 'снеге',
    'вода': 'воде', 'чай': 'чаю', 'огонь': 'огне', 'свет': 'свете', 'трава': 'траве',
    'цветок': 'цветке', 'дождь': 'дожде', 'ветер': 'ветре', 'луна': 'луне',
    'солнце': 'солнце', 'дом': 'доме', 'комната': 'комнате', 'стена': 'стене',
    'шкаф': 'шкафе', 'подушка': 'подушке', 'одеяло': 'одеяле', 'палка': 'палке',
    'камень': 'камне', 'ребёнок': 'ребёнке', 'ключ': 'ключе', 'лодка': 'лодке',
    'лес': 'лесу', 'звезда': 'звезде', 'пища': 'пище', 'звук': 'звуке',
    'тень': 'тени', 'туча': 'туче', 'роса': 'росе', 'песок': 'песке', 'нос': 'носе',
    'рот': 'роте', 'глаз': 'глазе', 'рука': 'руке', 'нога': 'ноге', 'ухо': 'ухе',
    'соль': 'соли', 'хлеб': 'хлебе', 'молоко': 'молоке', 'яблоко': 'яблоке',
    'гриб': 'грибе', 'лист': 'листе', 'ветка': 'ветке', 'земля': 'земле',
    'небо': 'небе', 'облако': 'облаке', 'река': 'реке', 'море': 'море',
    'берег': 'береге', 'тропа': 'тропе', 'мышь': 'мыши', 'заяц': 'зайце',
    'лиса': 'лисе', 'корова': 'корове', 'конь': 'коне', 'письмо': 'письме',
    'песня': 'песне', 'музыка': 'музыке', 'сказка': 'сказке', 'подарок': 'подарке',
    'деньги': 'деньгах', 'магазин': 'магазине', 'рассвет': 'рассвете',
    'закат': 'закате', 'утро': 'утре', 'вечер': 'вечере', 'зима': 'зиме',
    'лето': 'лете', 'праздник': 'празднике', 'зеркало': 'зеркале', 'часы': 'часах',
    'кольцо': 'кольце', 'монета': 'монете', 'бутылка': 'бутылке', 'ведро': 'ведре',
    'корзина': 'корзине', 'платок': 'платке', 'смысл': 'смысле', 'время': 'времени',
    'сон': 'сне', 'путь': 'пути', 'вкус': 'вкусе', 'запах': 'запахе', 'гость': 'госте'}

VERB = {'сидеть': 'сидит', 'спать': 'спит', 'стоять': 'стоит', 'лежать': 'лежит',
    'читать': 'читает', 'видеть': 'видит', 'открывать': 'открывает', 'мыть': 'моет',
    'ломать': 'ломает', 'искать': 'ищет', 'включать': 'включает', 'гасить': 'гасит',
    'любить': 'любит', 'есть': 'ест', 'светить': 'светит', 'расти': 'растёт',
    'падать': 'падает', 'шуметь': 'шумит', 'гореть': 'горит', 'пить': 'пьёт',
    'брать': 'берёт', 'класть': 'кладёт', 'писать': 'пишет', 'смотреть': 'смотрит',
    'плыть': 'плывёт', 'ждать': 'ждёт', 'находить': 'находит', 'терять': 'теряет',
    'покупать': 'покупает', 'слышать': 'слышит', 'чувствовать': 'чувствует'}

PREP_V = {'сидеть': 'на', 'спать': 'на', 'стоять': 'на', 'лежать': 'на', 'пить': 'из'}

AGENT = {'человек': 40, 'ребёнок': 8, 'кот': 6, 'собака': 5, 'птица': 2,
    'конь': 2, 'корова': 2, 'лиса': 1, 'заяц': 1, 'мышь': 1}

AGENT_VERBS = {
    'человек': ['читать', 'видеть', 'открывать', 'мыть', 'искать', 'включать',
        'гасить', 'любить', 'есть', 'сидеть', 'спать', 'стоять', 'лежать', 'брать',
        'класть', 'писать', 'смотреть', 'ждать', 'находить', 'терять', 'покупать',
        'чувствовать', 'слышать'],
    'ребёнок': ['сидеть', 'спать', 'видеть', 'любить', 'смотреть', 'ждать'],
    'кот': ['спать', 'лежать', 'сидеть', 'есть', 'видеть'],
    'собака': ['спать', 'лежать', 'сидеть', 'есть'],
    'птица': ['сидеть', 'спать', 'видеть'],
    'конь': ['спать', 'есть', 'видеть'],
    'корова': ['есть', 'спать', 'лежать'],
    'лиса': ['спать', 'видеть'],
    'заяц': ['спать', 'есть'],
    'мышь': ['есть', 'спать']}

VERB_OBJ = {'читать': ['книга'], 'видеть': ['окно', 'свет', 'звезда', 'дом', 'сон',
    'рассвет', 'закат', 'река', 'берег', 'мышь', 'заяц', 'лиса', 'корова', 'конь'],
    'открывать': ['дверь', 'окно'], 'мыть': ['чашка', 'тарелка', 'бутылка', 'ведро'],
    'ломать': ['палка'], 'искать': ['ключ', 'монета', 'платок', 'подарок', 'смысл'],
    'включать': ['лампа'], 'гасить': ['свет'], 'любить': ['кот', 'собака'],
    'есть': ['пища', 'яблоко', 'хлеб', 'гриб'], 'писать': ['письмо'],
    'смотреть': ['звезда', 'луна', 'огонь', 'облако', 'море', 'зеркало', 'часы'],
    'брать': ['яблоко', 'хлеб', 'соль', 'монета', 'платок', 'бутылка', 'ведро', 'корзина'],
    'класть': ['книга', 'палка', 'письмо', 'соль'], 'ждать': ['закат', 'рассвет'],
    'находить': ['ключ', 'подарок', 'монета'], 'терять': ['ключ', 'монета', 'письмо'],
    'покупать': ['хлеб', 'молоко', 'подарок', 'кольцо'],
    'слышать': ['звук', 'песня', 'музыка'], 'чувствовать': ['запах', 'вкус']}

LOC_OBJ = {'сидеть': ['стул', 'табурет', 'диван', 'пол', 'камень'],
    'спать': ['кровать', 'диван'], 'стоять': ['стол', 'шкаф', 'машина'],
    'лежать': ['пол', 'кровать', 'песок', 'трава']}

INTRANS = {'светить': ['лампа', 'солнце'], 'гореть': ['огонь', 'лампа'],
    'расти': ['трава', 'цветок', 'ребёнок'], 'падать': ['дождь', 'снег', 'лист'],
    'шуметь': ['дождь', 'ветер', 'машина'], 'плыть': ['облако', 'лодка'],
    'стоять': ['конь', 'шкаф', 'стол', 'машина']}

ADJ_LEM = {'деревянный': ['деревянный', 'деревянная', 'деревянное'],
    'круглый': ['круглый', 'круглая', 'круглое'], 'мягкий': ['мягкий', 'мягкая', 'мягкое'],
    'белый': ['белый', 'белая', 'белое'], 'горячий': ['горячий', 'горячая', 'горячее'],
    'холодный': ['холодный', 'холодная', 'холодное'], 'тёплый': ['тёплый', 'тёплая', 'тёплое'],
    'быстрый': ['быстрый', 'быстрая', 'быстрое'], 'высокий': ['высокий', 'высокая', 'высокое'],
    'большой': ['большой', 'большая', 'большое'], 'тяжёлый': ['тяжёлый', 'тяжёлая', 'тяжёлое'],
    'зелёный': ['зелёный', 'зелёная', 'зелёное'], 'красный': ['красный', 'красная', 'красное'],
    'тёмный': ['тёмный', 'тёмная', 'тёмное'], 'маленький': ['маленький', 'маленькая', 'маленькое'],
    'сладкий': ['сладкий', 'сладкая', 'сладкое'], 'глубокий': ['глубокий', 'глубокая', 'глубокое'],
    'тихий': ['тихий', 'тихая', 'тихое'], 'громкий': ['громкий', 'громкая', 'громкое'],
    'сухой': ['сухой', 'сухая', 'сухое'], 'мокрый': ['мокрый', 'мокрая', 'мокрое'],
    'новый': ['новый', 'новая', 'новое'], 'старый': ['старый', 'старая', 'старое'],
    'красивый': ['красивый', 'красивая', 'красивое'], 'длинный': ['длинный', 'длинная', 'длинное']}

PROPS = {'стул': [('деревянный', 'деревянный')], 'табурет': [('деревянный', 'деревянный')],
    'стол': [('деревянный', 'деревянный'), ('круглый', 'круглый')],
    'кровать': [('мягкий', 'мягкая')], 'диван': [('мягкий', 'мягкий')],
    'подушка': [('мягкий', 'мягкая'), ('белый', 'белая')], 'одеяло': [('тёплый', 'тёплое')],
    'чашка': [('белый', 'белая'), ('маленький', 'маленькая')],
    'тарелка': [('круглый', 'круглая'), ('белый', 'белая')],
    'дверь': [('деревянный', 'деревянная'), ('высокий', 'высокая')],
    'окно': [('большой', 'большое')], 'снег': [('белый', 'белый'), ('холодный', 'холодный')],
    'вода': [('холодный', 'холодная')], 'чай': [('горячий', 'горячий')],
    'огонь': [('горячий', 'горячий')], 'солнце': [('горячий', 'горячее'), ('круглый', 'круглое')],
    'луна': [('круглый', 'круглая')],
    'трава': [('зелёный', 'зелёная'), ('мокрый', 'мокрая')],
    'машина': [('быстрый', 'быстрая'), ('красный', 'красная'), ('красивый', 'красивая')],
    'ветер': [('холодный', 'холодный'), ('быстрый', 'быстрый')],
    'дом': [('большой', 'большой')], 'камень': [('тяжёлый', 'тяжёлый'), ('сухой', 'сухой')],
    'туча': [('тёмный', 'тёмная')], 'роса': [('холодный', 'холодная')],
    'яблоко': [('сладкий', 'сладкое')], 'хлеб': [('сухой', 'сухой')],
    'река': [('глубокий', 'глубокая')], 'лес': [('тихий', 'тихий')],
    'звук': [('громкий', 'громкий'), ('тихий', 'тихий')], 'облако': [('белый', 'белое')],
    'стена': [('белый', 'белая')], 'книга': [('новый', 'новая')],
    'шкаф': [('старый', 'старый')], 'песня': [('громкий', 'громкая')],
    'сказка': [('старый', 'старая')], 'путь': [('длинный', 'длинный')],
    'соль': [('белый', 'белая')], 'молоко': [('белый', 'белое')],
    'сон': [('глубокий', 'глубокий')]}

PART_ACC = {'спинка': 'спинку', 'сиденье': 'сиденье', 'ножка': 'ножку', 'ручка': 'ручку',
    'страница': 'страницу', 'крыша': 'крышу', 'ствол': 'ствол', 'крыло': 'крыло',
    'лапа': 'лапу', 'стекло': 'стекло', 'колесо': 'колесо', 'ветка': 'ветку',
    'обложка': 'обложку', 'руль': 'руль', 'горлышко': 'горлышко'}

PARTS = {'стул': ['спинка', 'сиденье', 'ножка'], 'табурет': ['сиденье', 'ножка'],
    'стол': ['ножка'], 'кровать': ['спинка'], 'чашка': ['ручка'], 'дверь': ['ручка'],
    'книга': ['страница', 'обложка'], 'дом': ['крыша'], 'дерево': ['ствол', 'ветка'],
    'птица': ['крыло'], 'кот': ['лапа'], 'собака': ['лапа'],
    'машина': ['колесо', 'руль'], 'окно': ['стекло'], 'бутылка': ['горлышко']}

OBJECTS = ['стул', 'табурет', 'стол', 'кровать', 'диван', 'пол', 'окно', 'чашка',
    'стакан', 'тарелка', 'кот', 'собака', 'птица', 'дерево', 'лампа', 'книга',
    'дверь', 'машина', 'снег', 'вода', 'чай', 'огонь', 'свет', 'трава', 'цветок',
    'дождь', 'ветер', 'луна', 'солнце', 'дом', 'стена', 'шкаф', 'подушка',
    'одеяло', 'палка', 'камень', 'ключ', 'лодка', 'лес', 'звезда', 'пища', 'звук',
    'туча', 'роса', 'песок', 'соль', 'хлеб', 'молоко', 'яблоко', 'гриб', 'лист',
    'ветка', 'облако', 'река', 'море', 'берег', 'мышь', 'заяц', 'лиса', 'корова',
    'конь', 'письмо', 'песня', 'музыка', 'сказка', 'подарок', 'рассвет', 'закат',
    'зеркало', 'часы', 'кольцо', 'монета', 'бутылка', 'ведро', 'корзина', 'платок',
    'смысл', 'сон', 'путь', 'вкус', 'запах']

# словарная лемматизация: строим LEM из всех форм
LEM = {}
for _k, _v in ACC.items(): LEM[_v] = _k
for _k, _v in PREP.items(): LEM[_v] = _k
for _k, _v in VERB.items(): LEM[_v] = _k
for _k, _v in PART_ACC.items(): LEM[_v] = _k
for _adj, _forms in ADJ_LEM.items():
    for _f in _forms: LEM[_f] = _adj
LEM['чашки'] = 'чашка'; LEM['стакана'] = 'стакан'; LEM['спинки'] = 'спинка'
LEM['книги'] = 'книга'; LEM['это'] = 'это'; LEM['имеет'] = 'имеет'
# тождественные отображения: именительный падеж и основы слов остаются сами собой
for _w in (set(ACC) | set(PREP) | set(VERB) | set(PART_ACC) | set(OBJECTS)
        | set(ADJ_LEM) | {p for ps in PARTS.values() for p in ps}):
    LEM.setdefault(_w, _w)

KNOWN = set(LEM.values()) | set(ACC) | set(PREP) | set(VERB) | set(PART_ACC.values()) | set(PART_ACC)

_FALL_ENDINGS = ('ами', 'ями', 'ов', 'ев', 'ах', 'ях', 'ой', 'ом', 'ем', 'ей',
    'ий', 'ый', 'ая', 'яя', 'ое', 'ее', 'ые', 'ую', 'юю', 'ам', 'ям',
    'я', 'ю', 'е', 'а', 'ы', 'и', 'у', 'ь', 'й', 'о')


def _fallback_lemma(w):
    # запасная схема: словарь, потом срезание окончаний и подбор по корню
    if w in LEM: return LEM[w]
    for suf in _FALL_ENDINGS:
        if len(w) - len(suf) >= 3 and w.endswith(suf):
            base = w[:-len(suf)]
            for cand in (base, base + 'а', base + 'я', base + 'о', base + 'ь', base + 'й'):
                if cand in KNOWN: return cand
    return w


def _lem(w):
    if _morph is not None:
        p = _morph.parse(w)
        if p: return p[0].normal_form
        return w
    return _fallback_lemma(w)


def read_book(path):
    # txt или pdf -> текст
    if path.lower().endswith('.pdf'):
        try:
            import fitz
            doc = fitz.open(path)
            return chr(10).join(p.get_text() for p in doc)
        except ImportError:
            print('нужен pymupdf: pip install pymupdf')
            return ''
        except Exception:
            return ''
    try:
        raw = open(path, 'rb').read()
    except Exception:
        return ''
    for enc in ('utf-8', 'cp1251'):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            pass
    return raw.decode('utf-8', errors='ignore')


EXAMPLE_BOOK = ('Врач ставит диагноз пациенту и назначает лечение. '
    'Вакцина формирует иммунитет и защищает организм от вируса. '
    'Воспаление вызывает боль и повышение температуры. '
    'Лекарство снижает температуру и лечит воспаление тканей. '
    'Болезнь ослабляет организм, поэтому врач назначает лекарство и покой. '
    'Иммунитет защищает от болезней. Врач и вакцина формируют иммунитет у пациента. '
    'Пациент чувствует боль, врач лечит пациента. Лекарство защищает ткани от вируса.')


def gen_corpus(n=6000):
    ag = list(AGENT.keys())
    agp = np.array([AGENT[a] for a in ag], float); agp /= agp.sum()
    parts_pool = [(nn, p) for nn, ps in PARTS.items() for p in ps]
    props_pool = [(nn, a) for nn, ps in PROPS.items() for a, _ in ps]
    int_pool = [(v, o) for v, os_ in INTRANS.items() for o in os_]
    S = []
    for _ in range(n):
        r = np.random.rand()
        if r < 0.55:
            a = ag[int(np.random.choice(len(ag), p=agp))]
            v = np.random.choice(AGENT_VERBS[a])
            if v in VERB_OBJ:
                S.append('%s %s %s' % (a, VERB[v], ACC[np.random.choice(VERB_OBJ[v])]))
            else:
                o = np.random.choice(LOC_OBJ[v])
                S.append('%s %s на %s' % (a, VERB[v], PREP[o]))
        elif r < 0.70:
            nn, p = parts_pool[int(np.random.randint(len(parts_pool)))]
            S.append('%s имеет %s' % (nn, PART_ACC[p]))
        elif r < 0.90:
            nn, af = props_pool[int(np.random.randint(len(props_pool)))]
            S.append('это %s %s' % (af, nn))
        elif r < 0.98:
            v, o = int_pool[int(np.random.randint(len(int_pool)))]
            S.append('%s %s' % (o, VERB[v]))
        else:
            S.append('человек пьёт чай из чашки' if np.random.rand() < 0.5
                else 'человек пьёт воду из стакана')
        if np.random.rand() < 0.002:
            S.append('табурет это стул без спинки')
    return [s.split() for s in S]


SEED_SEQS = [[LEM[t] for t in s if t in LEM] for s in gen_corpus()]


# ============ рабочее пространство: порождающий chi ============
DECAY, THETA, K, BETA = 0.8, 1.0, 3, 1.2
RHO_RATE = 0.3
HUNGER = 'голод'


class WS:
    # chi(z)=1 <=> a_z >= THETA и z в top-K. Доминанта = argmax a.
    def __init__(self):
        self.a = defaultdict(float)
        self.W = []
        self.focus = None
        self.shifts = []

    def inject(self, name, x):
        self.a[name] += x

    def broadcast(self, nb):
        for z in list(self.W):
            for j, w in nb.get(z, []):
                self.a[j] += BETA * w

    def step(self, t):
        self.a = defaultdict(float, {k: v * DECAY for k, v in self.a.items() if v > 1e-3})
        ranked = sorted(self.a.items(), key=lambda kv: -kv[1])
        self.W = [k for k, v in ranked if v >= THETA][:K]
        focus = self.W[0] if self.W else None
        if focus is not None and focus != self.focus:
            self.shifts.append((t, self.focus, focus))
            self.focus = focus
        if self.W:
            self.a['rho'] += RHO_RATE
        return self.W


# ============ MLP-предиктор: 32 -> 16 -> 32 ============
class MLP:
    def __init__(self, din, dh, dout, lr=0.03):
        self.W1 = np.random.randn(din, dh) * 0.3
        self.b1 = np.zeros(dh)
        self.W2 = np.random.randn(dh, dout) * 0.3
        self.b2 = np.zeros(dout)
        self.lr = lr

    def forward(self, x):
        h = np.tanh(x @ self.W1 + self.b1)
        return h @ self.W2 + self.b2, h

    def learn(self, x, y):
        yh, h = self.forward(x)
        e = yh - y
        d2 = e / len(y)
        gW2 = np.outer(h, d2)
        d1 = (self.W2 @ d2) * (1.0 - h * h)
        gW1 = np.outer(x, d1)
        self.W2 -= self.lr * gW2; self.b2 -= self.lr * d2
        self.W1 -= self.lr * gW1; self.b1 -= self.lr * d1
        return float(np.mean(e ** 2))

    def predict(self, x):
        yh, _ = self.forward(x)
        return yh


class Task:
    # задача: предсказать вектор b по вектору a; завершение по плато ошибки
    def __init__(self, name, pairs, reward=1.0):
        self.name = name
        self.pairs = list(pairs)
        self.reward = reward
        self.hist = {i: [] for i in range(len(self.pairs))}
        self.done = False

    def err(self, i):
        h = self.hist.get(i, [])
        return sum(h) / len(h) if h else 1.0

    def plateau(self):
        if not self.hist:
            return False
        if all(len(h) >= 40 for h in self.hist.values()):
            if max(self.err(i) for i in self.hist) < 0.06:
                return True
        if all(len(h) >= 60 for h in self.hist.values()):
            if all(h[-30] - h[-1] < 0.01 for h in self.hist.values()):
                return True
        return False


# ============ живой агент: гомеостаз + задачи + книги + генерация + QA ============
class Live:
    def __init__(self, seed_seqs=None):
        self.seq = list(seed_seqs) if seed_seqs is not None else []
        self.tasks = []
        self._preds = {}
        self.exclude_ideas = set()
        self.rebuild()
        self.ws = WS()
        self.hunger = 0.35
        self.budget = 0.0
        self.meals = 0
        self.tasks_done = 0
        self.t = 0
        self.log = []
        self.focus = None
        self._lock = threading.Lock()

    # ---------- память: PPMI -> SVD -> граф + биграммы + факты ----------
    def rebuild(self):
        cnt = Counter()
        for s in self.seq:
            cnt.update(s)
        top = sorted(cnt, key=lambda w: -cnt[w])[:MAXV]
        V = sorted(top)
        idx = {w: i for i, w in enumerate(V)}
        C = sum(cnt[w] for w in V)
        if C == 0:
            C = 1
        M = np.zeros((len(V), len(V)))
        co = Counter()
        for s in self.seq:
            ss = [w for w in s if w in idx]
            for i in range(len(ss)):
                for j in range(i + 1, min(len(ss), i + 4)):
                    if ss[i] != ss[j]:
                        M[idx[ss[i]], idx[ss[j]]] += 1
                        M[idx[ss[j]], idx[ss[i]]] += 1
                        co[(ss[i], ss[j])] += 1
                        co[(ss[j], ss[i])] += 1
        for w in V:
            M[idx[w], idx[w]] += cnt[w]
        u = np.array([cnt[w] for w in V], float) / C
        with np.errstate(divide='ignore', invalid='ignore'):
            P = np.maximum(0, np.log2((M / C) / np.outer(u, u)))
        P = np.nan_to_num(P, neginf=0.0)
        d = min(32, len(V))
        UU, sv, _ = np.linalg.svd(P, full_matrices=False)
        X = UU[:, :d] * sv[:d]
        X /= (np.linalg.norm(X, axis=1, keepdims=True) + 1e-9)
        self.V, self.idx, self.cnt, self.C = V, idx, cnt, C
        self.PPMI_, self.X_, self.co_ = P, X, co
        self.nb = {}
        for n in V:
            lst = [(j, min(1.0, co.get((n, j), 0) / cnt[n])) for j in V
                if j != n and co.get((n, j), 0) > 0]
            self.nb[n] = sorted(lst, key=lambda x: -x[1])[:8]
        self.bigrams = defaultdict(Counter)
        for s in self.seq:
            ss = [w for w in s if w in idx]
            for i in range(len(ss) - 1):
                self.bigrams[ss[i]][ss[i + 1]] += 1
        self.facts = defaultdict(set)
        self.rev_facts = defaultdict(set)
        for s in self.seq:
            if len(s) >= 3:
                if s[1] in VERB:
                    self.facts[(s[0], s[1])].add(s[2])
                    self.rev_facts[(s[1], s[2])].add(s[0])
                elif s[1] == 'имеет':
                    self.facts[(s[0], 'имеет')].add(s[2])
        self._verb_set = set(VERB)
        self.remap_tasks()

    def remap_tasks(self):
        keep = []
        for t in self.tasks:
            t.pairs = [(a, b) for (a, b) in t.pairs if a in self.idx and b in self.idx]
            t.hist = {i: t.hist.get(i, [])[:10] for i in range(len(t.pairs))}
            if t.pairs:
                keep.append(t)
        self.tasks = keep

    # ---------- лемматизация слова агентом ----------
    def lemmatize(self, w):
        return _lem(w)

    # ---------- обучение и награда ----------
    def study(self, task):
        paid = 0.0
        for i, (a, b) in enumerate(task.pairs):
            if a not in self.idx or b not in self.idx:
                continue
            p = task.hist.setdefault(i, [])
            pred = self._preds.get((task.name, i))
            if pred is None:
                d = self.X_.shape[1]
                pred = self._preds[(task.name, i)] = MLP(d, 16, d)
            old = task.err(i)
            e = pred.learn(self.X_[self.idx[a]], self.X_[self.idx[b]] * 3.0)
            p.append(e)
            new = task.err(i)
            gain = max(0.0, old - new) * 8.0
            self.budget += gain
            paid += gain
            self.ws.inject('учёба', 0.15 + gain)
        if task.plateau() and not task.done:
            task.done = True
            self.tasks_done += 1
            self.budget += task.reward
            self.log.append((self.t, 'задача выполнена: %s (+%.1f)' % (task.name, task.reward)))
        return paid

    # ---------- идеи ----------
    def best_idea(self):
        best, bn = None, -1.0
        for i in range(len(self.V)):
            a = self.V[i]
            if a in self.exclude_ideas:
                continue
            for b in self.V[i + 1:]:
                if b in self.exclude_ideas:
                    continue
                c_ij = self.co_.get((a, b), 0)
                p_ij = c_ij / self.C if c_ij > 0 else (self.cnt[a] * self.cnt[b]) / self.C ** 2
                H = -np.log2(max(p_ij, 1e-12))
                n = H * (1.0 - float(self.X_[self.idx[a]] @ self.X_[self.idx[b]]))
                if n > bn:
                    best, bn = (a, b), n
        return best, bn

    def make_idea_task(self):
        pair, n = self.best_idea()
        if pair is None:
            return None
        a, b = pair
        self.exclude_ideas.add(a)
        self.exclude_ideas.add(b)
        return Task('идея:%s|%s' % (a, b), [(a, b)], 1.0)

    # ---------- гомеостаз ----------
    def step(self):
        self.t += 1
        self.hunger = min(1.0, self.hunger + 0.003)
        v_c, v_cr = 0.35, 0.85
        drive = ((self.hunger - v_c) / (1 - v_c)) ** 2 if self.hunger > v_c else 0.0
        if self.hunger >= v_cr:
            drive += 5 * (self.hunger - v_cr)
        if drive > 0:
            self.ws.inject(HUNGER, drive)
        self.ws.broadcast(self.nb)
        self.ws.step(self.t)
        if self.ws.focus != self.focus:
            self.log.append((self.t, 'фокус: %s' % self.ws.focus))
            self.focus = self.ws.focus
        if self.ws.focus == HUNGER:
            if self.tasks and not all(t.done for t in self.tasks):
                self.study(next(t for t in self.tasks if not t.done))
            elif self.budget >= 0.5:
                spend = min(self.budget, 0.4)
                self.budget -= spend
                self.hunger = max(0.0, self.hunger - spend * 0.6)
                self.meals += 1
                self.log.append((self.t, 'еда №%d (голод %.2f)' % (self.meals, self.hunger)))
            elif self.tasks:
                self.study(self.tasks[-1])
        else:
            if self.tasks and not all(t.done for t in self.tasks):
                if np.random.rand() < 0.5:
                    self.study(next((t for t in self.tasks if not t.done), self.tasks[0]))
            elif np.random.rand() < 0.03:
                t = self.make_idea_task()
                if t:
                    self.tasks.append(t)

    def run(self, n):
        for _ in range(n):
            self.step()

    # ---------- книги ----------
    def learn_book(self, text, name='книга'):
        new = []
        n_tokens = 0
        sents = [p.strip() for p in re.split(r'[.!?;]+', text)
            if len(p.strip()) > 10]
        for sent in sents:
            toks = re.findall(r'[а-яёa-z-]+', sent.lower())
            seq = []
            for t in toks:
                if t in STOP or len(t) < 2:
                    continue
                lw = self.lemmatize(t)
                if lw not in self.idx:
                    new.append(lw)
                seq.append(lw)
            n_tokens += len(seq)
            if len(seq) >= 2:
                self.seq.append(seq)
        self.rebuild()
        made = 0
        existing = [tuple(x) for tsk in self.tasks for x in tsk.pairs]
        for (a, b), c in sorted(self.co_.items(), key=lambda kv: -kv[1]):
            if a in new and b in self.idx and c >= 2 and (a, b) not in existing:
                self.tasks.append(Task('авто:%s>%s' % (a, b), [(a, b)], 1.0))
                made += 1
                if made >= 5:
                    break
        return n_tokens, new, made

    # ---------- генерация: биграммы + антизацикливание + векторный backoff ----------
    def answer(self, seed_word, length=10):
        w = self.lemmatize(seed_word)
        if w not in self.idx:
            return 'не знаю слова «%s»' % seed_word
        cur = w
        out = [cur]
        recent = deque([cur], maxlen=6)
        for _ in range(length):
            cands = [c for c in self.bigrams.get(cur, {}) if c not in recent]
            if not cands:
                # перескок: ближайший по смыслу сосед с продолжениями
                sims = sorted(((self.V[i], float(self.X_[self.idx[cur]] @ self.X_[i]))
                    for i in range(len(self.V))), key=lambda x: -x[1])
                pool = [c for c, _ in sims[:15]]
                jump = None
                for cand in pool:
                    if cand in recent:
                        continue
                    if self.bigrams.get(cand):
                        jump = cand
                        break
                if jump is None:
                    for cand in self.V:
                        if cand in recent:
                            continue
                        if self.bigrams.get(cand):
                            jump = cand
                            break
                if jump is None:
                    break
                out.append(jump)
                recent.append(jump)
                cur = jump
                continue
            weights = np.array([1.0 + 6.0 * max(0.0, float(self.X_[self.idx[cur]] @ self.X_[self.idx[c]]))
                for c in cands])
            nxt = cands[int(np.random.choice(len(cands), p=weights / weights.sum()))]
            out.append(nxt)
            recent.append(nxt)
            cur = nxt
        return ' '.join(out).capitalize() + '.'

    def neighbors(self, w, k=6):
        v = self.X_[self.idx[w]]
        sims = sorted(((self.V[i], float(v @ self.X_[i])) for i in range(len(self.V))
            if self.V[i] != w), key=lambda x: -x[1])
        return sims[:k]

    # ---------- QA: факты -> векторный поиск ----------
    def ask(self, question):
        raw = re.findall(r'[а-яё-]+', question.lower())
        m = re.search(r'что\s+так(?:ое|а)\s+([а-яё-]+)', question.lower())
        if m:
            w = self.lemmatize(m.group(1))
            if w in self.idx:
                sims = [x for x, _ in self.neighbors(w, 6)]
                return 'что такое %s: рядом в памяти: %s' % (w, ', '.join(sims))
            return 'не знаю слова «%s»' % m.group(1)
        ql = [self.lemmatize(t) for t in raw if t not in STOP and len(t) > 2]
        ql = [w for w in ql if w in self.idx]
        if not ql:
            return 'не понял вопроса'
        verbs = [w for w in ql if w in self._verb_set]
        nouns = [w for w in ql if w not in self._verb_set]
        if verbs:
            hits = []
            for v in verbs:
                for n in nouns:
                    for o in self.facts.get((n, v), ()):
                        hits.append('%s %s %s' % (n, VERB.get(v, v), o))
                if not nouns:
                    for (s0, v0), objs in self.facts.items():
                        if v0 == v:
                            for o in list(objs)[:2]:
                                hits.append('%s %s %s' % (s0, VERB.get(v0, v0), o))
            if hits:
                return '; '.join(hits[:4]) + '.'
            hits = []
            for v in verbs:
                for n in nouns:
                    for s0 in self.rev_facts.get((v, n), ()):
                        hits.append('%s %s %s' % (s0, VERB.get(v, v), n))
            if hits:
                return '; '.join(hits[:4]) + '.'
        qv = np.mean([self.X_[self.idx[w]] for w in ql], axis=0)
        qv /= (np.linalg.norm(qv) + 1e-9)
        best_s, best_sc = None, -1
        for s in self.seq:
            ws_ = [w for w in s if w in self.idx]
            if not ws_:
                continue
            sv_ = np.mean([self.X_[self.idx[w]] for w in ws_], axis=0)
            sv_ /= (np.linalg.norm(sv_) + 1e-9)
            cov = sum(1 for w in ql if w in s) / float(len(ql))
            sc = float(qv @ sv_) + 0.5 * cov
            if sc > best_sc:
                best_s, best_sc = s, sc
        if best_s is None:
            return 'не нашёл ответа'
        return ' '.join(best_s).capitalize() + '.'

    def vector_str(self, w):
        w = self.lemmatize(w)
        if w not in self.idx:
            return 'нет в словаре'
        sims = self.neighbors(w, 6)
        return ', '.join('%s %.2f' % (a, s) for a, s in sims)

    def sude_live(self, noun):
        noun = self.lemmatize(noun)
        cands = [(v, self.co_.get((noun, v), 0) / max(1, self.cnt[noun]))
            for v in self.V if self.co_.get((noun, v), 0) > 0]
        if not cands:
            return 'нет суждений'
        v, w = max(cands, key=lambda x: x[1])
        return '%s — %s (p = %.2f)' % (noun, v, w)

    # ---------- состояние ----------
    def _state_path(self):
        return os.path.join(os.path.expanduser('~'), 'io_state.pkl')

    def save(self, path=None):
        if path is None:
            path = self._state_path()
        preds = {'%s|%d' % k: (p.W1.tolist(), p.b1.tolist(), p.W2.tolist(), p.b2.tolist())
            for k, p in self._preds.items()}
        st = dict(seq=self.seq, hunger=self.hunger, budget=self.budget, meals=self.meals,
            tasks_done=self.tasks_done, t=self.t, log=self.log,
            tasks=[dict(name=t_.name, pairs=t_.pairs, reward=t_.reward,
                hist={str(k): v for k, v in t_.hist.items()}, done=t_.done)
                for t_ in self.tasks],
            excl=list(self.exclude_ideas), preds=preds)
        with open(path, 'wb') as f:
            pickle.dump(st, f)
        return path

    def load(self, path=None):
        if path is None:
            path = self._state_path()
        with open(path, 'rb') as f:
            st = pickle.load(f)
        self.seq = st['seq']
        self.rebuild()
        self.hunger, self.budget = st['hunger'], st['budget']
        self.meals, self.tasks_done, self.t = st['meals'], st['tasks_done'], st['t']
        self.log = st['log']
        self.exclude_ideas = set(st['excl'])
        self._preds = {}
        for key, (W1, b1, W2, b2) in st['preds'].items():
            name, i = key.rsplit('|', 1)
            d = self.X_.shape[1]
            p = MLP(d, 16, d)
            p.W1 = np.array(W1); p.b1 = np.array(b1)
            p.W2 = np.array(W2); p.b2 = np.array(b2)
            self._preds[(name, int(i))] = p
        self.tasks = []
        for td in st['tasks']:
            t_ = Task(td['name'], [tuple(p_) for p_ in td['pairs']], td['reward'])
            t_.hist = {int(k): v for k, v in td['hist'].items()}
            t_.done = td['done']
            self.tasks.append(t_)
        return True


# ============ консольный режим (резерв, если нет kivy) ============
INTERACTIVE_HELP = """команды:
книга <путь> — выучить книгу (txt/pdf); "книга пример" — встроенный текст
шаг <N> — прожить N шагов
ответь <слово> — сгенерировать предложение
спроси <вопрос> — спросить по знаниям
вектор <слово> — связи слова
суждение <слово> — сильнейшая связь
статус — голод, бюджет, задачи
сохранить / загрузить — состояние памяти
выход"""


def live_main():
    ag = Live(SEED_SEQS)
    if os.path.exists(ag._state_path()):
        try:
            ag.load()
            print('память загружена')
        except Exception:
            pass
    print('Ио жив. лемм: %d | токенов: %d' % (len(ag.V), ag.C))
    print(INTERACTIVE_HELP)
    for line in sys.stdin:
        cmd = line.strip()
        if not cmd:
            continue
        parts = cmd.split(maxsplit=1)
        op = parts[0].lower()
        arg = parts[1] if len(parts) > 1 else ''
        if op in ('выход', 'quit', 'exit'):
            break
        elif op == 'книга':
            text = EXAMPLE_BOOK if arg == 'пример' else read_book(arg)
            if text:
                nt, nw, na = ag.learn_book(text)
                print('выучено токенов: %d | новых слов: %s | задач создано: %d' % (
                    nt, ', '.join(nw[:8]) if nw else '-', na))
        elif op == 'шаг':
            try:
                ag.run(int(arg) if arg else 10)
            except ValueError:
                ag.run(10)
            print('шагов прожито: %d' % ag.t)
        elif op == 'ответь':
            print(ag.answer(arg))
        elif op == 'спроси':
            print(ag.ask(arg))
        elif op == 'вектор':
            print(ag.vector_str(arg))
        elif op == 'суждение':
            print(ag.sude_live(arg))
        elif op == 'статус':
            print('лемм: %d | фактов: %d | задач: %d (выполнено %d) | голод: %.2f | бюджет: %.2f | шаг: %d' % (
                len(ag.V), sum(len(v) for v in ag.facts.values()), len(ag.tasks),
                ag.tasks_done, ag.hunger, ag.budget, ag.t))
        elif op == 'сохранить':
            print('сохранено в', ag.save())
        elif op == 'загрузить':
            try:
                ag.load()
                print('память загружена')
            except Exception as ex:
                print('не смог загрузить: %s' % ex)


# ============ графический интерфейс: Ио ============
def run_app():
    from kivy.app import App
    from kivy.uix.screenmanager import ScreenManager, Screen
    from kivy.uix.floatlayout import FloatLayout
    from kivy.uix.boxlayout import BoxLayout
    from kivy.uix.gridlayout import GridLayout
    from kivy.uix.scrollview import ScrollView
    from kivy.uix.label import Label
    from kivy.uix.button import Button
    from kivy.uix.textinput import TextInput
    from kivy.uix.tabbedpanel import TabbedPanel, TabbedPanelItem
    from kivy.clock import Clock
    from kivy.core.window import Window

    Window.clearcolor = (0, 0, 0, 1)

    AGENT_MODEL = Live(SEED_SEQS)
    if os.path.exists(AGENT_MODEL._state_path()):
        try:
            AGENT_MODEL.load()
        except Exception:
            pass

    class Splash(Screen):
        # загрузочный экран: 3 секунды, чёрный фон, белое Ио, подпись снизу
        def __init__(self, **kw):
            super(Splash, self).__init__(**kw)
            fl = FloatLayout()
            fl.add_widget(Label(text='Ио', font_size='110sp', bold=True,
                color=(1, 1, 1, 1)))
            lbl = Label(text='by Artem Tizhoev', font_size='13sp',
                color=(0.65, 0.65, 0.65, 1),
                pos_hint={'center_x': 0.5, 'y': 0.16})
            fl.add_widget(lbl)
            self.add_widget(fl)

        def on_enter(self, *args):
            Clock.schedule_once(self._go, 3.0)

        def _go(self, dt):
            self.manager.current = 'main'

    class IoApp(App):
        title = 'Ио'

        def build(self):
            sm = ScreenManager()
            sm.add_widget(Splash(name='splash'))
            sm.add_widget(self._main_screen())
            return sm

        def _main_screen(self):
            root = BoxLayout(orientation='vertical', padding=6, spacing=4)
            tp = TabbedPanel(do_default_tab=False)
            tp.tab_width = 160

            # ---- вкладка Обучение ----
            learn_box = BoxLayout(orientation='vertical', padding=8, spacing=6)
            learn_box.add_widget(Label(text='Путь к папке с книгами (txt, pdf):',
                size_hint=(1, None), height=24, halign='left'))
            self.path_input = TextInput(text='/storage/emulated/0/Books',
                multiline=False, size_hint=(1, None), height=36)
            learn_box.add_widget(self.path_input)
            btns = GridLayout(cols=2, spacing=6, size_hint=(1, None), height=120)
            b1 = Button(text='Обучить библиотеку')
            b1.bind(on_press=lambda x: self.learn_library())
            b2 = Button(text='Демо-корпус')
            b2.bind(on_press=lambda x: self.demo_corpus())
            b3 = Button(text='Сон (пересобрать память)')
            b3.bind(on_press=lambda x: self.sleep_now())
            b4 = Button(text='Сохранить память')
            b4.bind(on_press=lambda x: self.save_state())
            b5 = Button(text='Загрузить память')
            b5.bind(on_press=lambda x: self.load_state())
            b6 = Button(text='Прожить 100 шагов')
            b6.bind(on_press=lambda x: self.run_steps(100))
            for b in (b1, b2, b3, b4, b5, b6):
                btns.add_widget(b)
            learn_box.add_widget(btns)
            self.learn_log = Label(text='журнал обучения:', size_hint=(1, None),
                height=28, halign='left')
            learn_box.add_widget(self.learn_log)
            sv = ScrollView()
            self.log_label = Label(text='готов', size_hint_y=None, halign='left',
                valign='top', font_size='13sp')
            self.log_label.bind(width=lambda inst, w: setattr(inst, 'text_size', (w, None)))
            self.log_label.bind(texture_size=lambda inst, ts: setattr(inst, 'height', ts[1]))
            sv.add_widget(self.log_label)
            learn_box.add_widget(sv)
            t1 = TabbedPanelItem(text='Обучение')
            t1.add_widget(learn_box)
            tp.add_widget(t1)

            # ---- вкладка Знания ----
            know_box = BoxLayout(orientation='vertical', padding=8, spacing=6)
            know_box.add_widget(Label(text='Запрос по знаниям:', size_hint=(1, None), height=24))
            self.q_input = TextInput(multiline=False, size_hint=(1, None), height=36,
                hint_text='например: кто читает книгу? или что такое стул')
            know_box.add_widget(self.q_input)
            bq = Button(text='Спросить', size_hint=(1, None), height=44)
            bq.bind(on_press=lambda x: self.do_ask())
            know_box.add_widget(bq)
            self.answer_label = Label(text='', font_size='15sp',
                size_hint=(1, None), height=110, halign='left', valign='top')
            self.answer_label.bind(width=lambda inst, w: setattr(inst, 'text_size', (w, None)))
            know_box.add_widget(self.answer_label)
            know_box.add_widget(Label(text='Слово для генерации и суждения:',
                size_hint=(1, None), height=24))
            self.w_input = TextInput(multiline=False, size_hint=(1, None), height=36)
            know_box.add_widget(self.w_input)
            bg = GridLayout(cols=3, spacing=6, size_hint=(1, None), height=44)
            bgen = Button(text='Сгенерировать')
            bgen.bind(on_press=lambda x: self.do_generate())
            bsude = Button(text='Суждение')
            bsude.bind(on_press=lambda x: self.do_sude())
            bvec = Button(text='Вектор')
            bvec.bind(on_press=lambda x: self.do_vector())
            bg.add_widget(bgen); bg.add_widget(bsude); bg.add_widget(bvec)
            know_box.add_widget(bg)
            self.gen_label = Label(text='', font_size='15sp', size_hint=(1, None),
                height=110, halign='left', valign='top')
            self.gen_label.bind(width=lambda inst, w: setattr(inst, 'text_size', (w, None)))
            know_box.add_widget(self.gen_label)
            t2 = TabbedPanelItem(text='Знания')
            t2.add_widget(know_box)
            tp.add_widget(t2)

            # ---- вкладка Статус ----
            stat_box = BoxLayout(orientation='vertical', padding=8, spacing=6)
            self.stat_label = Label(text='', font_size='14sp', halign='left', valign='top')
            self.stat_label.bind(width=lambda inst, w: setattr(inst, 'text_size', (w, None)))
            stat_box.add_widget(self.stat_label)
            bref = Button(text='Обновить', size_hint=(1, None), height=40)
            bref.bind(on_press=lambda x: self.refresh_status())
            stat_box.add_widget(bref)
            t3 = TabbedPanelItem(text='Статус')
            t3.add_widget(stat_box)
            tp.add_widget(t3)

            root.add_widget(tp)
            self.refresh_status()
            return root

        # ---- действия ----
        def _log(self, msg):
            def _do(dt):
                cur = self.log_label.text
                self.log_label.text = (cur + chr(10) + msg)[-4000:]
            Clock.schedule_once(_do, 0)

        def learn_library(self):
            path = self.path_input.text.strip()
            self._log('начинаю обучение: %s' % path)

            def work():
                try:
                    if not os.path.isdir(path):
                        self._log('папка не найдена: %s' % path)
                        return
                    files = [os.path.join(dp, fn) for dp, _, fns in os.walk(path)
                        for fn in fns if fn.lower().endswith(('.txt', '.pdf'))]
                    if not files:
                        self._log('не найдено книг (txt/pdf) в папке')
                        return
                    total = 0
                    for fp in files:
                        text = read_book(fp)
                        if text:
                            nt, nw, na = AGENT_MODEL.learn_book(text)
                            total += nt
                            self._log('%s: %d токенов, новых слов %d, задач %d' % (
                                os.path.basename(fp), nt, len(nw), na))
                    self._log('готово: файлов %d, всего токенов %d' % (len(files), total))
                except Exception:
                    self._log('ошибка: ' + traceback.format_exc()[-300:])
            threading.Thread(target=work, daemon=True).start()

        def demo_corpus(self):
            def work():
                try:
                    nt, nw, na = AGENT_MODEL.learn_book(
                        ' '.join(' '.join(s) for s in SEED_SEQS[:2000]))
                    self._log('демо-корпус: %d токенов, новых слов %d' % (nt, len(nw)))
                except Exception:
                    self._log('ошибка: ' + traceback.format_exc()[-300:])
            threading.Thread(target=work, daemon=True).start()

        def sleep_now(self):
            def work():
                try:
                    AGENT_MODEL.rebuild()
                    self._log('сон: память пересобрана, лемм %d' % len(AGENT_MODEL.V))
                except Exception:
                    self._log('ошибка: ' + traceback.format_exc()[-300:])
            threading.Thread(target=work, daemon=True).start()

        def save_state(self):
            def work():
                try:
                    p = AGENT_MODEL.save()
                    self._log('память сохранена: %s' % p)
                except Exception:
                    self._log('ошибка сохранения: ' + traceback.format_exc()[-300:])
            threading.Thread(target=work, daemon=True).start()

        def load_state(self):
            def work():
                try:
                    AGENT_MODEL.load()
                    self._log('память загружена, лемм %d' % len(AGENT_MODEL.V))
                except Exception:
                    self._log('ошибка загрузки: ' + traceback.format_exc()[-300:])
            threading.Thread(target=work, daemon=True).start()

        def run_steps(self, n):
            def work():
                try:
                    AGENT_MODEL.run(n)
                    self._log('прожито шагов: %d' % AGENT_MODEL.t)
                except Exception:
                    self._log('ошибка: ' + traceback.format_exc()[-300:])
            threading.Thread(target=work, daemon=True).start()

        def do_ask(self):
            q = self.q_input.text.strip()
            if not q:
                return
            self.answer_label.text = AGENT_MODEL.ask(q)

        def do_generate(self):
            w = self.w_input.text.strip()
            if w:
                self.gen_label.text = AGENT_MODEL.answer(w)

        def do_sude(self):
            w = self.w_input.text.strip()
            if w:
                self.gen_label.text = AGENT_MODEL.sude_live(w)

        def do_vector(self):
            w = self.w_input.text.strip()
            if w:
                self.gen_label.text = AGENT_MODEL.vector_str(w)

        def refresh_status(self):
            ag = AGENT_MODEL
            facts = sum(len(v) for v in ag.facts.values())
            self.stat_label.text = (
                'Ио — состояние\nлемм в словаре: %d\nтокенов в памяти: %d\n'
                'фактов: %d\nзадач: %d (выполнено: %d)\nголод: %.2f\nбюджет: %.2f\n'
                'шагов прожито: %d' % (len(ag.V), ag.C, facts, len(ag.tasks),
                ag.tasks_done, ag.hunger, ag.budget, ag.t))

    IoApp().run()


if __name__ == '__main__':
    try:
        import kivy  # noqa: F401
        run_app()
    except ImportError:
        live_main()
