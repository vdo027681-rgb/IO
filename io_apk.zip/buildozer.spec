[app]
title = Ио
package.name = io
package.domain = org.artemtizhoev
source.dir = .
source.include_exts = py,png,jpg,kv,txt
version = 1.3
requirements = python3,kivy,numpy,pymorphy3,pymupdf
orientation = portrait
fullscreen = 0
android.permissions = READ_EXTERNAL_STORAGE,WRITE_EXTERNAL_STORAGE
android.api = 31
android.minapi = 24
android.archs = arm64-v8a
presplash.color = #000000
[buildozer]
log_level = 2
